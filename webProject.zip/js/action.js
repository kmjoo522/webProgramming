$(document).ready(function(){

	$.ajax({
		url : "https://project-f7254.firebaseio.com/Contents.json",
		method : "GET",
		success : function(data){
			insertHtml(data);
		}
	});
});

function printObj(obj){
	var ret = "";
	if($.type(obj) == "string"){
		ret = obj;
	}
	else{
		for(var property in obj){
			printObj(obj[property]);
		}
	}
	console.log(ret);
}

function insertHtml(obj){
	var array = $.map(obj, function(value, index) {
		return [value];
	});
	
	var size = 0;
	var keys = new Array();
	
	for(var tmp in obj){
		size++;
		keys.push(tmp);
	}

	var contents = new Array(); 

	for(var tmp in array){
			contents.push(array[tmp]);
	}

	for(var i=size-1; i>=0; i--){

		var data = new Array(); // date, inputData, title, category, file, hashtag 
		
		for(var tmp in contents[i]){
			data.push(contents[i][tmp]);
		}
	
		var contentsDiary = document.getElementById('window');
		var realtimeblock = document.createElement('div'); 
		realtimeblock.className = 'realtimeblock';
		
		var diaryBox = document.createElement('div');
		diaryBox.className = 'diaryBox';
		
		var diaryhr = document.createElement('hr');

		var img = new Image();
		if(data[3]=="일상"){
			img.src = "img/1.png";
		}
		else if(data[3] == "계획"){
			img.src = "img/2.jpg";	
		}
		else{
			img.src = "img/3.jpg";
		}

		var diaryTitle = document.createElement('span');
		var titleText = document.createTextNode(data[2]);
		diaryTitle.className = 'diaryTitle';
		diaryTitle.appendChild(titleText);
		
		var date = document.createElement('div');
		var dateText = document.createTextNode(data[0]);
		date.className = 'date';
		date.appendChild(dateText);
		
		var hashtag = document.createElement('div');
		hashtag.className = 'hashtag';
		var spanTag = document.createElement('span');
		var hashText = document.createTextNode(data[5])
		spanTag.appendChild(hashText);
		hashtag.appendChild(spanTag);

		var realtimeDetail = document.createElement('div');
		realtimeDetail.className = 'realtimeDetail';
		var detailText = document.createTextNode(data[1]);
		realtimeDetail.appendChild(detailText);

		var file = document.createElement('div');
		file.className = 'file';
		var fileText = document.createTextNode(data[4]);
		file.appendChild(fileText);
	//	file.setAttribute("onclick","downloadFile('"+data[4]+"');");

		var contentBtn = document.createElement('div');
		contentBtn.className = 'contentBtn';
		var update = document.createElement('input');
		update.className = 'update';
		update.setAttribute("type", "button");
		update.setAttribute("value", "수정");
		var updateURL = "update.html?"+keys[i];
		update.setAttribute("onclick", "location.href='"+updateURL+"'");
		var del = document.createElement('input');
		del.className = 'delete';
		del.setAttribute("type", "button");
		del.setAttribute("value", "삭제");
		del.setAttribute("onclick", "deleteContent('"+keys[i]+"');");

		contentBtn.appendChild(update);
		contentBtn.appendChild(del);
		diaryBox.appendChild(diaryhr);
		diaryBox.appendChild(img);
		diaryBox.appendChild(diaryTitle);
		diaryBox.appendChild(date);
		diaryBox.appendChild(hashtag);
		diaryBox.appendChild(realtimeDetail);
		diaryBox.appendChild(file);
		diaryBox.appendChild(contentBtn);
		contentsDiary.appendChild(realtimeblock).appendChild(diaryBox);
		
	}
	//스크롤
	var width = "100%";
	var height = $(window).height()-70;
	var maxWidth = $(window).width();

	var contentsDiary = $(".contentsDiary");
	//var scrollrealtimeblock = $(".realtimeblock");
	
	for(var i=0; i<contentsDiary.length; i++){
		//$(scrollrealtimeblock[i]).setAttribute("style", "width :" + width+ ";height : "+ height + "px");
		$(contentsDiary[i]).css("width", width+"px");
		$(contentsDiary[i]).css("height", height+"px");
		//$(scrollrealtimeblock[i]).css("margin-top", 50+"px");

		var items = $(contentsDiary[i]).find(".realtimeblock");
		items.css({"width" : width, "height" : height + "px"});
		contentsDiary[i].pageLen = items.length;
		contentsDiary[i].currentPage = items.length > 0 ? 1 : 0;
		contentsDiary[i].isAnimate = false;

		$(contentsDiary[i]).on("mousewheel", function(event){
					if(event.originalEvent.wheelDelta <= 0){
						if(!this.isAnimate && this.currentPage < this.pageLen){
							this.isAnimate = true;
							this.currentPage++;

							if(maxWidth <= 600){
								$(this).find("#window").animate({
									"top" : (((this.currentPage-1) * (height+10)) * -1) + "px"
								}, 800, function(){
									$(this).parent()[0].isAnimate =false;
								});	
							}
							else{
								$(this).find("#window").animate({
									"top" : (((this.currentPage-1) * (height+20)) * -1) + "px"
								}, 800, function(){
									$(this).parent()[0].isAnimate =false;
								});	
							}
						}
					}
					else{
						if(!this.isAnimate && this.currentPage > 1){
							this.isAnimate = true;
							this.currentPage --;
							
							if(maxWidth <= 600){
								$(this).find("#window").animate({
									"top" : (((this.currentPage-1) * (height+10)) * -1) + "px"
								}, 800, function(){
									$(this).parent()[0].isAnimate =false;
								});	
							}
							else{
								$(this).find("#window").animate({
									"top" : (((this.currentPage-1) * (height+20)) * -1) + "px"
								}, 800, function(){
									$(this).parent()[0].isAnimate =false;
								});	
							}
						}
					}
				});
	}
	
}

function deleteContent(key){
	if(confirm("정말 삭제하시겠습니까??") == true){
		
		$.ajax({
			url : "https://project-f7254.firebaseio.com/Contents/"+key+".json",
			method : "DELETE",
			success : function(data){
				window.location.reload();
			}
		});
		
	}
}

function downloadFile(name){
	// Create a reference to the file we want to download
	var config =
        {
            apiKey: " AIzaSyD6YTy4YSt0i4daK-thxsW6CmVfYzRkTY0",
            storageBucket: "project-f7254.appspot.com",
        };
	firebase.initializeApp(config);

	var filename = "uploadFiles/"+name;
	console.log(filename);
	var storageRef = firebase.storage().ref();
	var starsRef = storageRef.child(filename);

	starsRef.getDownloadURL().then(function(url) {
	  // `url` is the download URL for 'images/stars.jpg'

	  // This can be downloaded directly:
	  var xhr = new XMLHttpRequest();
	  xhr.responseType = 'blob';
	  xhr.onload = function(event) {
	    var blob = xhr.response;
	  };
	  xhr.open('GET', url);
	  xhr.send();

	}).catch(function(error) {
	  // Handle any errors
	});
}