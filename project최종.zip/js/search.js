var keyword;
var count = 0;

$(document).ready(function(){  
    
    $("#searchProject").keyup(function(){
        keyword = $("#searchProject").val().length;
        count++;
       
        if(event.keyCode == 13){
            $("#searchResult").slideDown("slow");
            count = 0;
            showContents();
            return; 
        }

        if (keyword <  1) {
            $("#searchResult").slideUp("slow");
            count = 0;
            return;        
        }

    }); 
});

function showContents(){
    var searchTag = document.getElementById('searchProject').value;

    $.ajax({
        url : "https://project-f7254.firebaseio.com/Contents.json",
        method : "GET",
        success : function(data){
            insertHashTag(data, searchTag);
        }
    });
}

function insertHashTag(obj, searchTag){
    var array = $.map(obj, function(value, index) {
        return [value];
    });
    //console.log(array);
    var size = 0;
    var keys = new Array();
    var hashTag = new Array();
    
    for(var tmp in obj){
        size++;
        keys.push(tmp);
    }

    var contents = new Array(); 

    for(var tmp in array){
        contents.push(array[tmp]);
    }

    var check = 0;

    //초기화
    var removeContent = document.getElementById('searchResultTable');
    removeContent.innerHTML = "";

    for(var i in contents){
        console.log(contents[i]);
        var data = new Array(); // date, inputData, title, category, file, hashtag 
        for(var tmp in contents[i]){
            data.push(contents[i][tmp]);
        }
  
        var hashtag = data[5].split('#');
        console.log(searchTag);

        for(var i in hashtag){
            hashtag[i]=hashtag[i].trim();
        }

        var state = "false";

        for(var i in hashtag){
            if(hashtag[i] == searchTag){
                console.log(hashtag[i]+"-"+searchTag);
                state = "true";
            }
        }

        if(state == "false") {
            check += 1;

            if(check == size){
                var searchResult = document.getElementById('searchResult');
               
                var noneResult = document.createElement('div');
                var inputText = document.createTextNode("해시태그 검색 결과가 없습니다");
                noneResult.id = 'noneResult';
                noneResult.appendChild(inputText);

                searchResult.appendChild(noneResult);
            }
            else continue;
        }
        else{
            // date, inputData, title, category, hashtag
            var searchResultTable = document.getElementById('searchResultTable');
            var insertTd = document.createElement('td');

            var hashContent = document.createElement('div');
            hashContent.className = 'hashContent';
            hashContent.setAttribute("style","margin-left : 10px");

            var diaryTitle = document.createElement('div');
            var title = document.createTextNode(data[2]);
            diaryTitle.className = 'diaryTitle';
            diaryTitle.appendChild(title);

            var date = document.createElement('div');
            var dateText = document.createTextNode(data[0]);
            date.className = 'date';
            date.appendChild(dateText);

            var hashElement = document.createElement('div');
            hashElement.className = 'hashtag';
            var spanTag = document.createElement('span');
            var hashText = document.createTextNode(data[5])
            spanTag.appendChild(hashText);
            hashElement.appendChild(spanTag);

            var realtimeDetail = document.createElement('div');
            realtimeDetail.className = 'realtimeDetail';
            var detailText = document.createTextNode(data[1]);
            realtimeDetail.appendChild(detailText);

           // diaryTitle.className = 'diaryTitle';
            hashContent.appendChild(diaryTitle);
            hashContent.appendChild(date);
            hashContent.appendChild(hashElement);
            hashContent.appendChild(realtimeDetail);
            insertTd.appendChild(hashContent);
            searchResultTable.appendChild(insertTd);
        }       
    }
}

