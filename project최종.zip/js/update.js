$(document).ready(function(){
	var temp=location.href.split("?");

	var address = location.href;
	//console.log(temp[1]);

	$.ajax({
		url : "https://project-f7254.firebaseio.com/Contents/"+temp[1]+".json",
		method : "GET",
		success : function(data){
			settingHTML(data);
		}
	});

});

var filename;

function settingHTML(object){
	var data = new Array(); // date, inputData, title, category, file, hashtag 
	
	for(var tmp in object){
		data.push(object[tmp]);
	}

	var category = document.getElementById('cat');
	for(var i in category){
		if(category.options[i].value == data[3]){
			category.selectedIndex = i;
			break;
		}
	}
	var date = document.getElementById('date');
	date.value = data[0];

	var title = document.getElementById('title');
	title.value = data[2];

	var hash = document.getElementById('inputHash');
	var inputHash = document.createTextNode(data[5]);
	hash.appendChild(inputHash);
	
	var tmp = CKEDITOR.instances['editor1'].setData(data[1]);
	var file = document.getElementById('fileName2');
	filename = data[4];
	file.setAttribute('placeholder',data[4]);
}

function updateData(){
	if(confirm("다이어리를 수정하시겠습니까???") == true){
			
		var temp=location.href.split("?");

		var title = document.getElementById('title').value;
		var date = document.getElementById('date').value;
		var category = document.getElementById('cat');
		var selected = category.options[category.selectedIndex].text;
		var hashArea = document.getElementById('inputHash').value;
		var inputContents = CKEDITOR.instances.editor1.getData();
		
		var config =
		{
			apiKey: " AIzaSyD6YTy4YSt0i4daK-thxsW6CmVfYzRkTY0",
			storageBucket: "project-f7254.appspot.com",
	    };
		firebase.initializeApp(config);
		var signal = 1;

		var fileButton = document.getElementById('fileButton').files[0];
	//	console.log(fileButton);
		if(fileButton != null){
			var uploader = document.getElementById('uploader');
			var storageRef = firebase.storage().ref('uploadFiles/'+fileButton.name); 
			var task = storageRef.put(fileButton);
			filename = fileButton.name;
			task.on('state_changed', function progress(snapshot) {
	   			var percentage = (snapshot.bytesTransferred/snapshot.totalBytes)*100;
	    		uploader.value = percentage;

	 		}, function error(err) {

	   		},function complete() {
				alert("수정되었습니다");
				document.location.href = "main.html";
	    	});
		}
		else{
			signal = 0;
		}

		var input = {
			"날짜" : date,
			"내용" : inputContents,
			"제목" : title,
			"카테고리" : selected,
			"해시태그" : hashArea,	
			"파일" : filename,
		};

		$.ajax({
			url : "https://project-f7254.firebaseio.com/Contents/"+temp[1]+".json",
			method : "PUT",
			data : JSON.stringify(input),
			success : function(data){
				if(signal == 0){
					alert("수정되었습니다");
					document.location.href = "main.html";
				}
			}
		});
	}
}
