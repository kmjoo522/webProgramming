$(document).ready(function(){

});

function sendData(){
	if(confirm("다이어리를 등록하시겠습니까???") == true){
		var title = document.getElementById('title').value;
		var date = document.getElementById('date').value;
		var category = document.getElementById('cat');
		var selected = category.options[category.selectedIndex].text;
		var hashArea = document.getElementById('hashArea').value;
		var inputContents = CKEDITOR.instances.editor1.getData();
		var config =
		{
			apiKey: " AIzaSyD6YTy4YSt0i4daK-thxsW6CmVfYzRkTY0",
			storageBucket: "project-f7254.appspot.com",
	    };
		firebase.initializeApp(config);
		var filename;
		var signal = 1;

		var fileButton = document.getElementById('fileButton').files[0];
		console.log(fileButton);
		if(fileButton != null){
			var uploader = document.getElementById('uploader');
			var storageRef = firebase.storage().ref('uploadFiles/'+fileButton.name); 
			filename = fileButton.name;
			var task = storageRef.put(fileButton);

			task.on('state_changed', function progress(snapshot) {
	   			var percentage = (snapshot.bytesTransferred/snapshot.totalBytes)*100;
	    		uploader.value = percentage;

	 		}, function error(err) {

	   		},function complete() {
				alert("등록되었습니다");
				document.location.href = "main.html";
	    	});
			
		}
		else{
			filename = " ";
			signal = 0;
		}
		var input = {
			"날짜" : date,
			"내용" : inputContents,
			"제목" : title,
			"카테고리" : selected,
			"해시태그" : hashArea,	
			"파일" : filename,
		};

		$.ajax({
		url : "https://project-f7254.firebaseio.com/Contents.json",
		method : "POST",
		data : JSON.stringify(input),
		success : function(data){	
			if(signal == 0){
				alert("등록되었습니다");
				document.location.href = "main.html";
			}
		}
	});
	}
}
